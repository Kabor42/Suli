#include "ustring.h"

#error "itt valósítsa meg az UString osztály tagfüggvényeit!"
#error "ne feledkezzen meg a statikus adattagról sem!"
