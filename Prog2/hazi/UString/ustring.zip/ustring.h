#ifndef USTRING_H
#define USTRING_H

#error "itt deklarálja az UString osztályt"

#endif // USTRING_H
